package com.domainlog.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.Instant
import java.time.ZoneId

data class DomainCount(val domain: String, val count: Int, val nets: String)

/** One hour of one day. [idx] is the elapsed hour since local midnight, [hour] the local clock hour. */
data class HourGroup(val idx: Int, val hour: Int, val total: Int, val domains: List<DomainCount>)

class DomainDb private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "domains.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE q (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ts INTEGER NOT NULL, domain TEXT NOT NULL, net TEXT NOT NULL)"
        )
        db.execSQL("CREATE INDEX q_ts ON q(ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(ts: Long, domain: String, net: String) {
        val cv = ContentValues().apply {
            put("ts", ts)
            put("domain", domain)
            put("net", net)
        }
        writableDatabase.insert("q", null, cv)
    }

    /** Lookups between [startMs] (local midnight) and [endMs], grouped by hour, then by domain. */
    fun hourly(startMs: Long, endMs: Long, zone: ZoneId): List<HourGroup> {
        // Values are Longs we computed ourselves, so inlining them is safe.
        val sql = """
            SELECT (ts - $startMs) / 3600000 AS h, domain, COUNT(*) AS c, GROUP_CONCAT(DISTINCT net)
            FROM q
            WHERE ts >= $startMs AND ts < $endMs
            GROUP BY h, domain
            ORDER BY h DESC, c DESC
        """.trimIndent()

        val byHour = LinkedHashMap<Int, MutableList<DomainCount>>()
        readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) {
                byHour.getOrPut(c.getInt(0)) { mutableListOf() }
                    .add(DomainCount(c.getString(1), c.getInt(2), c.getString(3) ?: ""))
            }
        }
        return byHour.map { (idx, list) ->
            val hour = Instant.ofEpochMilli(startMs + idx * 3_600_000L).atZone(zone).hour
            HourGroup(idx, hour, list.sumOf { it.count }, list)
        }
    }

    fun clear() {
        writableDatabase.delete("q", null, null)
    }

    fun purgeBefore(ts: Long) {
        writableDatabase.delete("q", "ts < ?", arrayOf(ts.toString()))
    }

    companion object {
        @Volatile
        private var instance: DomainDb? = null

        fun get(ctx: Context): DomainDb =
            instance ?: synchronized(this) {
                instance ?: DomainDb(ctx).also { instance = it }
            }
    }
}
