package com.domainlog.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) startLogging()
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                App(onToggle = ::toggle)
            }
        }
    }

    private fun toggle(on: Boolean) {
        if (!on) {
            startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
            return
        }
        val consent = VpnService.prepare(this) // shows Android's one-time VPN dialog
        if (consent != null) vpnPermission.launch(consent) else startLogging()
    }

    private fun startLogging() {
        ContextCompat.startForegroundService(this, Intent(this, DnsVpnService::class.java))
    }
}

private val dayFormat = DateTimeFormatter.ofPattern("EEE, d MMM yyyy")

private fun hourLabel(h: Int) = "%02d:00 – %02d:00".format(h, (h + 1) % 24)

private fun netLabel(nets: String) = nets.split(',').filter { it.isNotBlank() }.joinToString(" / ") {
    when (it) {
        "WIFI" -> "Wi-Fi"
        "CELLULAR" -> "Mobile"
        "ETHERNET" -> "Ethernet"
        else -> it.lowercase()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(onToggle: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val db = remember { DomainDb.get(ctx) }
    val zone = remember { ZoneId.systemDefault() }
    val scope = rememberCoroutineScope()

    val running by DnsVpnService.running.collectAsState()
    var day by remember { mutableStateOf(LocalDate.now()) }
    var groups by remember { mutableStateOf<List<HourGroup>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(setOf<Int>()) }
    var confirmClear by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    // Load the selected day; keep refreshing every 2 s while logging is on and today is shown.
    LaunchedEffect(day, running, reload) {
        while (true) {
            val start = day.atStartOfDay(zone).toInstant().toEpochMilli()
            val end = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            groups = withContext(Dispatchers.IO) { db.hourly(start, end, zone) }
            if (!(running && day == LocalDate.now())) break
            delay(2000)
        }
    }

    val q = query.trim().lowercase()
    val shown = remember(groups, q) {
        if (q.isEmpty()) groups else groups.mapNotNull { g ->
            val d = g.domains.filter { it.domain.contains(q) }
            if (d.isEmpty()) null else g.copy(total = d.sumOf { it.count }, domains = d)
        }
    }
    val totalLookups = shown.sumOf { it.total }
    val uniqueDomains = remember(shown) { shown.flatMap { g -> g.domains.map { it.domain } }.toSet().size }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DomainLog") },
                actions = {
                    TextButton(onClick = { confirmClear = true }) { Text("Clear") }
                    Switch(checked = running, onCheckedChange = onToggle)
                    Spacer(Modifier.width(12.dp))
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                if (running) "● Logging DNS lookups on every network"
                else "Stopped. Turn the switch on to start logging.",
                style = MaterialTheme.typography.bodyMedium,
            )

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(onClick = { day = day.minusDays(1) }) { Text("‹ Prev") }
                Text(day.format(dayFormat), style = MaterialTheme.typography.titleMedium)
                TextButton(
                    onClick = { day = day.plusDays(1) },
                    enabled = day.isBefore(LocalDate.now()),
                ) { Text("Next ›") }
            }

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search domain") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "$totalLookups lookups · $uniqueDomains unique domains",
                style = MaterialTheme.typography.labelLarge,
            )

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (shown.isEmpty()) {
                    item {
                        Text(
                            "No domains recorded for this day.",
                            modifier = Modifier.padding(top = 24.dp),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
                items(shown, key = { it.idx }) { g ->
                    val open = g.idx in expanded || q.isNotEmpty()
                    Card(
                        Modifier
                            .fillMaxWidth()
                            .clickable { expanded = if (g.idx in expanded) expanded - g.idx else expanded + g.idx }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    hourLabel(g.hour),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    "${g.total} lookups · ${g.domains.size} domains",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                            if (open) {
                                Spacer(Modifier.height(8.dp))
                                g.domains.forEach { d ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(
                                            d.domain,
                                            modifier = Modifier.weight(1f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            "${netLabel(d.nets)}  ×${d.count}",
                                            style = MaterialTheme.typography.bodySmall,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete all history?") },
            text = { Text("Every recorded domain, for every day, will be removed from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch {
                        withContext(Dispatchers.IO) { db.clear() }
                        reload++
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}
