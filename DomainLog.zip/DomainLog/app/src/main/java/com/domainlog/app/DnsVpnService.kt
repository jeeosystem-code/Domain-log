package com.domainlog.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * A local-only VPN. Only the (fake) DNS server address is routed into the tunnel, so the
 * rest of the device's traffic is untouched and keeps using Wi-Fi / mobile data / Ethernet
 * as normal. Every DNS query is read, its domain is logged, and the query is forwarded to the
 * real DNS server of whichever network is currently active.
 */
class DnsVpnService : VpnService() {

    private data class NetInfo(
        val network: Network,
        val type: String,
        val validated: Boolean,
        val dns: List<InetAddress>,
    )

    private val nets = ConcurrentHashMap<Network, NetInfo>()
    private lateinit var cm: ConnectivityManager
    private lateinit var db: DomainDb

    private var tun: ParcelFileDescriptor? = null
    private var readerThread: Thread? = null
    private val workers: ExecutorService = Executors.newFixedThreadPool(8)
    private val dbWriter: ExecutorService = Executors.newSingleThreadExecutor()

    // Only touched from the reader thread.
    private val recent = HashMap<String, Long>()

    @Volatile
    private var active = false

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = refresh(network)
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refresh(network)
        override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) = refresh(network)
        override fun onLost(network: Network) {
            nets.remove(network)
        }
    }

    override fun onCreate() {
        super.onCreate()
        cm = getSystemService(ConnectivityManager::class.java)
        db = DomainDb.get(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        startForegroundNotification()
        startVpn()
        return START_STICKY
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        teardown()
        workers.shutdownNow()
        dbWriter.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- lifecycle

    private fun startVpn() {
        if (active) return

        // Watch every non-VPN network so we always know the current DNS servers and network type.
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        cm.registerNetworkCallback(request, netCallback)
        @Suppress("DEPRECATION")
        cm.allNetworks.forEach { refresh(it) }

        val fd = Builder()
            .setSession("DomainLog")
            .setMtu(1500)
            .addAddress(VPN_ADDR, 24)
            .addDnsServer(DNS_ADDR)
            .addRoute(DNS_ADDR, 32) // only DNS goes through the tunnel
            .setBlocking(true)
            .establish()

        if (fd == null) {
            stopVpn()
            return
        }

        tun = fd
        active = true
        running.value = true
        readerThread = Thread({ readLoop(fd) }, "dns-reader").also { it.start() }

        // Keep 30 days of history.
        dbWriter.execute {
            runCatching { db.purgeBefore(System.currentTimeMillis() - 30L * 24 * 3600 * 1000) }
        }
    }

    private fun teardown() {
        active = false
        running.value = false
        runCatching { cm.unregisterNetworkCallback(netCallback) }
        runCatching { tun?.close() }
        tun = null
        nets.clear()
    }

    private fun stopVpn() {
        teardown()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "DNS logging", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("DomainLog is running")
            .setContentText("Recording domain lookups made on this device")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------------------------------------------------------- networks

    private fun refresh(n: Network) {
        val caps = cm.getNetworkCapabilities(n) ?: return
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return
        val lp = cm.getLinkProperties(n)
        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "BLUETOOTH"
            else -> "OTHER"
        }
        val dns = lp?.dnsServers.orEmpty().sortedBy { it is Inet6Address }
        nets[n] = NetInfo(
            n, type, caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED), dns
        )
    }

    /** Prefer a validated network, and Wi-Fi/Ethernet over mobile data. */
    private fun bestNet(): NetInfo? =
        nets.values
            .sortedWith(compareByDescending<NetInfo> { it.validated }.thenBy { it.type == "CELLULAR" })
            .firstOrNull()

    // ---------------------------------------------------------------- packet loop

    private fun readLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (active) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                handle(buf.copyOf(n), output)
            }
        } catch (_: IOException) {
            // tunnel closed
        } finally {
            if (active) stopVpn()
        }
    }

    private fun handle(p: ByteArray, out: FileOutputStream) {
        val n = p.size
        if (n < 28 || (p[0].toInt() shr 4) != 4) return // IPv4 only
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (p[9].toInt() != 17 || n < ihl + 8) return // UDP only
        if (u16(p, ihl + 2) != 53) return
        val srcPort = u16(p, ihl)
        val payload = minOf(u16(p, ihl + 4) - 8, n - ihl - 8)
        if (payload < 12) return

        val query = p.copyOfRange(ihl + 8, ihl + 8 + payload)
        parseQuestion(query)?.let { (name, type) -> log(name, type) }

        val clientIp = p.copyOfRange(12, 16)
        val dnsIp = p.copyOfRange(16, 20)
        workers.execute { forward(query, clientIp, dnsIp, srcPort, out) }
    }

    /** Returns (domain, query type) of the first question in a DNS query. */
    private fun parseQuestion(q: ByteArray): Pair<String, Int>? {
        if (u16(q, 4) < 1) return null
        var i = 12
        val sb = StringBuilder()
        while (i < q.size) {
            val len = q[i].toInt() and 0xFF
            if (len == 0) {
                i++
                break
            }
            if ((len and 0xC0) != 0 || i + 1 + len > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            for (k in 1..len) sb.append((q[i + k].toInt() and 0xFF).toChar())
            i += 1 + len
        }
        if (i + 2 > q.size) return null
        return sb.toString().lowercase() to u16(q, i)
    }

    private fun log(name: String, type: Int) {
        // A (1), AAAA (28) and HTTPS (65) lookups; a browser sends several at once, so de-duplicate.
        if (name.isEmpty() || (type != 1 && type != 28 && type != 65)) return
        if (name.endsWith(".arpa") || name.endsWith(".local")) return

        val now = System.currentTimeMillis()
        val last = recent[name]
        if (last != null && now - last < 2000) return
        recent[name] = now
        if (recent.size > 2000) recent.entries.removeIf { now - it.value > 2000 }

        val net = bestNet()?.type ?: "NONE"
        dbWriter.execute { runCatching { db.insert(now, name, net) } }
    }

    // ---------------------------------------------------------------- forwarding

    private fun forward(
        query: ByteArray, clientIp: ByteArray, dnsIp: ByteArray, clientPort: Int, out: FileOutputStream,
    ) {
        val info = bestNet() ?: return
        val servers = (info.dns + FALLBACKS).distinct().take(4)
        for (server in servers) {
            try {
                DatagramSocket().use { s ->
                    // Bind to the real network so the query bypasses our own tunnel.
                    try {
                        info.network.bindSocket(s)
                    } catch (_: Exception) {
                        protect(s)
                    }
                    s.soTimeout = 2500
                    s.connect(InetSocketAddress(server, 53))
                    s.send(DatagramPacket(query, query.size))
                    val buf = ByteArray(4096)
                    val dp = DatagramPacket(buf, buf.size)
                    s.receive(dp)
                    writeResponse(buf, dp.length, clientIp, dnsIp, clientPort, out)
                    return
                }
            } catch (_: Exception) {
                // try the next server
            }
        }
    }

    private fun writeResponse(
        resp: ByteArray, respLen: Int, clientIp: ByteArray, dnsIp: ByteArray, clientPort: Int,
        out: FileOutputStream,
    ) {
        var len = respLen
        if (len > 1472) { // would not fit the MTU: truncate and set the TC bit
            len = 1472
            resp[2] = (resp[2].toInt() or 0x02).toByte()
        }
        val total = 28 + len
        val pkt = ByteArray(total)
        pkt[0] = 0x45
        put16(pkt, 2, total)
        put16(pkt, 6, 0x4000)
        pkt[8] = 64
        pkt[9] = 17
        System.arraycopy(dnsIp, 0, pkt, 12, 4)
        System.arraycopy(clientIp, 0, pkt, 16, 4)
        put16(pkt, 10, checksum(pkt, 20))
        put16(pkt, 20, 53)
        put16(pkt, 22, clientPort)
        put16(pkt, 24, 8 + len) // UDP checksum left at 0 (allowed for IPv4)
        System.arraycopy(resp, 0, pkt, 28, len)
        synchronized(out) { out.write(pkt) }
    }

    private fun checksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) {
            sum += u16(b, i)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    private fun u16(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun put16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v shr 8).toByte()
        b[o + 1] = v.toByte()
    }

    companion object {
        const val ACTION_STOP = "com.domainlog.app.STOP"
        private const val CHANNEL = "dns"
        private const val VPN_ADDR = "10.111.222.1"
        private const val DNS_ADDR = "10.111.222.2"
        private val FALLBACKS: List<InetAddress> =
            listOf(InetAddress.getByName("1.1.1.1"), InetAddress.getByName("8.8.8.8"))

        val running = MutableStateFlow(false)
    }
}
