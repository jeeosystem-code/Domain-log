# DomainLog

Android app (Kotlin, Jetpack Compose) that records which domains this phone looks up, and shows them
**by date, then by hour**, on Wi-Fi, mobile data or Ethernet.

## Build and run
1. Open this folder in Android Studio (Ladybug or newer). Let it sync; accept the Gradle 8.9 wrapper if asked.
2. Run on a phone or emulator (Android 8.0 / API 26 or newer).
3. Turn the switch on and accept Android's one-time VPN dialog.

## How it works
- A `VpnService` creates a local tunnel and routes **only one fake DNS address** into it, so normal traffic is not touched.
- Each DNS query is read, the domain is stored in SQLite (on the device only), and the query is forwarded
  to the DNS server of the currently active network (re-detected when you switch Wi-Fi / mobile).
- The UI groups the day into 24 hourly cards (tap one to expand its domains with counts), with a domain search,
  previous/next day, and a Clear button. History older than 30 days is deleted automatically.

## Limits you should know about
- It sees **domain lookups**, not full URLs, page content or per-app usage. Cached lookups are not repeated.
- Apps that use encrypted DNS (Chrome "Secure DNS", Firefox DoH) or hard-coded IP addresses bypass it.
  Set Android **Private DNS** to *Off* or *Automatic*, and turn off in-browser secure DNS.
- Android allows one active VPN at a time, so it cannot run together with another VPN app.
- IPv4 DNS only in this version. Use it only on devices you own or where the user has agreed.
